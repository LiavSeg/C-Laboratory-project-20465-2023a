#include <stdio.h>
#include <ctype.h>
#define MAX_LINE_LENGTH 82

