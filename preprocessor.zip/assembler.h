#include<stdio.h>
void preprocessor(char *);
