#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct macro{
		
	char* name;
	char* content;
	
	struct macro* next;
	} macro;

